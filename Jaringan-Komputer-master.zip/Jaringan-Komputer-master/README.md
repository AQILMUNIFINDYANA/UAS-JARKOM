Link Presentasi Project Jarkom, Serta Config & Video Documentasi 
https://drive.google.com/file/d/17iZkWqHmToykKKK353oCCM3TQA6uTOR_/view?usp=sharing
